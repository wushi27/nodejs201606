//第一个程序。输入node 1.js执行。
console.log('hello,world');